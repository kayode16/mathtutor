EMIVANT WEBSITE UPDATE

FILES INCLUDED
1. index.html
2. thank-you.html

KEEP YOUR EXISTING PHOTO IN THE SAME GITHUB FOLDER:
segun-photo.jpg

IMPORTANT
- Confirm that the actual filename is exactly: segun-photo.jpg
- Replace your existing index.html with the included index.html.
- Upload thank-you.html beside index.html.
- Commit both files to the main branch.
- Netlify should deploy automatically.

NETLIFY FORM
After deployment:
1. Open your Netlify project.
2. Open Forms and confirm "free-mathematics-assessment" appears.
3. Open Project configuration > Notifications.
4. Add a form submission email notification.
5. Submit one test form from the live website.

PRICES
The package prices and lesson quantities are suggestions. Confirm the number and length of lessons before publishing.
